const titles = {
  dashboard:   'Dashboard',
  validations: 'Validations',
  users:       'Utilisateurs',
  prestations: 'Prestations',
  categories:  'Catégories',
  events:      'Événements',
  annonces:    'Annonces',
  conteneurs:  'Conteneurs',
  finances:    'Revenus'
};

function go(page, el) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-' + page).classList.add('active');
  document.getElementById('page-title').textContent = titles[page] || page;

  document.querySelectorAll('.sidebar nav a').forEach(a => a.classList.remove('active'));
  if (el) el.classList.add('active');

  document.querySelector('.content').scrollTop = 0;
}

function openModal(id) {
  document.getElementById(id).classList.add('open');
}

function closeModal(id, e) {
  if (!e || e.target.id === id) {
    document.getElementById(id).classList.remove('open');
  }
}

function filterTab(el) {
  el.closest('.tabs').querySelectorAll('button').forEach(b => {
    b.className = b === el ? 'btn btn-green btn-sm' : 'btn btn-ghost btn-sm';
  });
}

function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.style.display = 'block';
  setTimeout(() => t.style.display = 'none', 2500);
}
