module upcycleconnect

go 1.25.0

require github.com/go-sql-driver/mysql v1.8.1

require (
	filippo.io/edwards25519 v1.1.0 // indirect
	golang.org/x/crypto v0.50.0 // indirect
)
